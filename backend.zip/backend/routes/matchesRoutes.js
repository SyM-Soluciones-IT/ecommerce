// // backend/routes/matchesRoutes.js
// const express = require('express');
// const { db } = require('../models/Matches');

// const router = express.Router();

// // Ruta para obtener todos los partidos
// router.get('/', async (req, res) => {
//   try {
//     const [partidos] = await db.query('SELECT * FROM matches');
//     res.json(partidos);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// // Ruta para crear un nuevo partido
// // router.post('/crear-partido', async (req, res) => {
// //   const { tipo, id_torneo, resultado, id_jugador1, id_jugador2, id_jugador3, id_jugador4 } = req.body;

// //   // Comprobar que los campos no son undefined
// //   if (!tipo || !id_torneo) {
// //     return res.status(400).json({ message: 'El tipo de partido y el ID del torneo son obligatorios.' });
// //   }

// //   if (tipo === 'dobles' && (!id_jugador1 || !id_jugador2 || !id_jugador3 || !id_jugador4)) {
// //     return res.status(400).json({ message: 'Para partidos de dobles, se deben proporcionar 4 IDs de jugadores.' });
// //   }

// //   if (tipo === 'individual' && (!id_jugador1 || !id_jugador2)) {
// //     return res.status(400).json({ message: 'Para partidos individuales se deben proporcionar 2 IDs de jugadores.' });
// //   }

// //   try {
// //     const [result] = await db.query(
// //       'INSERT INTO matches (tipo, id_torneo, resultado, id_jugador1, id_jugador2, id_jugador3, id_jugador4) VALUES (?, ?, ?, ?, ?, ?, ?)',
// //       [tipo, id_torneo, JSON.stringify(resultado), id_jugador1, id_jugador2, id_jugador3, id_jugador4]
// //     );
// //     res.status(201).json({ id: result.insertId, tipo, id_torneo, resultado });
// //   } catch (err) {
// //     res.status(400).json({ message: err.message });
// //   }
// // });

// // Ruta para crear un nuevo partido
// router.post('/crear-partido', async (req, res) => {
//   const {type} = req.body;

//   // Comprobar que el tipo no es undefined
//   if (!type) {
//     return res.status(400).json({ message: 'El tipo de partido es obligatorio.' });
//   } 

//   try {
//     const [result] = await db.query(
//       'INSERT INTO matches (type) VALUES (?)',
//       [type]
//     );
//     res.status(201).json({ id: result.insertId, type });
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
// });

// // Ruta para obtener un partido por su ID
// router.get('/:id', async (req, res) => {
//   try {
//     const [rows] = await db.query('SELECT * FROM partidos WHERE id = ?', [req.params.id]);
//     if (rows.length === 0) {
//       return res.status(404).json({ message: 'Partido no encontrado' });
//     }
//     res.json(rows[0]);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// // Ruta para actualizar un partido por su ID
// // router.put('/modificar-partido/:id', async (req, res) => {
// //   const { tipo, id_torneo, resultado, id_jugador1, id_jugador2, id_jugador3, id_jugador4 } = req.body;

// //   // Comprobar que el tipo y el ID del torneo no son undefined
// //   if (!tipo || !id_torneo) {
// //     return res.status(400).json({ message: 'El tipo de partido y el ID del torneo son obligatorios.' });
// //   }

// //   try {
// //     const [result] = await db.query(
// //       'UPDATE partidos SET tipo = ?, id_torneo = ?, resultado = ?, id_jugador1 = ?, id_jugador2 = ?, id_jugador3 = ?, id_jugador4 = ? WHERE id = ?',
// //       [tipo, id_torneo, JSON.stringify(resultado), id_jugador1, id_jugador2, id_jugador3, id_jugador4, req.params.id]
// //     );
// //     if (result.affectedRows === 0) {
// //       return res.status(404).json({ message: 'Partido no encontrado' });
// //     }
// //     res.json({ message: 'Partido actualizado correctamente' });
// //   } catch (err) {
// //     res.status(500).json({ message: err.message });
// //   }
// // });

// // Ruta para actualizar un partido por su ID
// router.put('/modificar-partido/:id', async (req, res) => {
//   const { type } = req.body;

//   // Comprobar que el tipo de torneo no es undefined
//   if (!type) {
//     return res.status(400).json({ message: 'El tipo de partido es obligatorio.' });
//   }

//   try {
//     const [result] = await db.query(
//       'UPDATE matches SET type = ? WHERE id = ?',
//       [type, req.params.id]
//     );
//     if (result.affectedRows === 0) {
//       return res.status(404).json({ message: 'Partido no encontrado' });
//     }
//     res.json({ message: 'Partido actualizado correctamente' });
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });


// // Ruta para eliminar un partido por su ID
// router.delete('/eliminar-partido/:id', async (req, res) => {
//   try {
//     const [result] = await db.query('DELETE FROM matches WHERE id = ?', [req.params.id]);
//     if (result.affectedRows === 0) {
//       return res.status(404).json({ message: 'Partido no encontrado' });
//     }
//     res.json({ message: 'Partido eliminado correctamente' });
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// });

// module.exports = router;

const express = require("express");
const router = express.Router();
const matchesController = require("../controllers/MatchController");
const authMiddleware = require("../middleware/authMiddleware");

// Ruta para todos los usuarios (solo autenticación)
router.get("/",  matchesController.getMatches);
router.get("/:id", matchesController.getMatchById);

// Ruta para usuarios administradores (autenticación + admin)
router.post("/create", authMiddleware(true), matchesController.createMatch);
router.put("/:id", authMiddleware(true), matchesController.updateMatch);
router.delete("/:id", authMiddleware(true), matchesController.deleteMatchById);

module.exports = router;