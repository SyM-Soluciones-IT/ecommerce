const db = require("../config/database");

const CategoryModel = {
  // Obtener categoría por ID si está visible
  async getCategoryById(id) {
    try {
      const pool = await db();
      const [rows] = await pool.query("SELECT * FROM categories WHERE id = ? AND visible = 1", [id]);
      return rows[0];
    } catch (err) {
      console.error("Error ejecutando la consulta:", err);
      throw err;
    }
  },

  // Obtener todas las categorías visibles
  async getCategories() {
    try {
      const pool = await db();
      const [rows] = await pool.query("SELECT * FROM categories WHERE visible = 1");
      return rows;
    } catch (err) {
      console.error("Error ejecutando la consulta:", err);
      throw err;
    }
  },

  // Crear una nueva categoría con visible = 1
  async createCategory(nombre) {
    try {
      const pool = await db();
      const [result] = await pool.query(
        "INSERT INTO categories (name, visible) VALUES (?, 1)",
        [nombre]
      );
      return result.insertId;
    } catch (err) {
      console.error("Error ejecutando la consulta:", err);
      throw err;
    }
  },

  // Actualizar una categoría solo si está visible
  async updateCategory(id, nombre) {
    try {
      const pool = await db();
      const [result] = await pool.query(
        "UPDATE categories SET name = ? WHERE id = ? AND visible = 1",
        [nombre, id]
      );
      return result;
    } catch (err) {
      console.error("Error ejecutando la consulta:", err);
      throw err;
    }
  },

  // Borrado lógico de una categoría (visible = 0)
  async deleteCategoryById(id) {
    try {
      const pool = await db();
      const [result] = await pool.query(
        "UPDATE categories SET visible = 0 WHERE id = ? AND visible = 1",
        [id]
      );
      return result;
    } catch (err) {
      console.error("Error ejecutando la consulta:", err);
      throw err;
    }
  },
};

module.exports = CategoryModel;
