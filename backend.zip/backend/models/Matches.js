const db = require("../config/database");

const MatchesModel = {
  // Obtener todos los partidos
  async getMatches() {
    try {
      const pool = await db();
      const [rows] = await pool.query("SELECT * FROM matches WHERE visible = 1");
      return rows;
    } catch (err) {
      console.error("Error ejecutando la consulta:", err);
      throw err;
    }
  },

  async getMatchById(id) {
    try {
      const pool = await db();
      const [rows] = await pool.query("SELECT * FROM matches WHERE id = ? AND visible = 1", [id]);
      return rows[0];
    } catch (err) {
      console.error("Error ejecutando la consulta:", err);
      throw err;
    }
  },

  async createMatch(type) {
    try {
      const pool = await db();
      const [result] = await pool.query("INSERT INTO matches (type, visible) VALUES (?, 1)", [type]);
      return result.insertId;
    } catch (err) {
      console.error("Error ejecutando la consulta:", err);
      throw err;
    }
  },

  async updateMatch(id, type) {
    try {
      const pool = await db();
      const [result] = await pool.query("UPDATE matches SET type = ? WHERE id = ? AND visible = 1", [type, id]);
      return result;
    } catch (err) {
      console.error("Error ejecutando la consulta:", err);
      throw err;
    }
  },

  async deleteMatchById(id) {
    try {
      const pool = await db();
      const [result] = await pool.query("UPDATE matches SET visible = 0 WHERE id = ? AND visible = 1", [id]);
      return result;
    } catch (err) {
      console.error("Error ejecutando la consulta:", err);
      throw err;
    }
  },

};

module.exports = MatchesModel;