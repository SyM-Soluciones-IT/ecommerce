const MatchesModel = require("../models/Matches");

const getMatches = async (req, res) => {
    try {
        const matches = await MatchesModel.getMatches();
        if (!matches || matches.length === 0) {
            return res.status(404).json({ message: "Partidos no encontrados" });
        }
        res.json(matches);
    } catch (error) {
        res.status(500).json({ error: "Error en la base de datos" });
    }
};

const getMatchById = async (req, res) => {
    const { id } = req.params;
    try {
        const match = await MatchesModel.getMatchById(id);
        if (!match) {
            return res.status(404).json({ message: "Partido no encontrado o no visible" });
        }
        res.json(match);
    } catch (error) {
        res.status(500).json({ error: "Error en la base de datos" });
    }
};

const createMatch = async (req, res) => {
    const { type } = req.body;
    try {
        if (!type) {
            return res.status(400).json({ message: "El tipo de partido es obligatorio" });
        }
        const result = await MatchesModel.createMatch(type);
        res.status(201).json({ id: result.insertId, type });
    } catch (error) {
        res.status(500).json({ error: "Error en la base de datos" });
    }
};

const updateMatch = async (req, res) => {
    const { id } = req.params;
    const { type } = req.body;
    try {
        if (!type) {
            return res.status(400).json({ message: "El tipo de partido es obligatorio" });
        }
        const result = await MatchesModel.updateMatch(id, type);
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Partido no encontrado o no visible" });
        }
        res.json({ message: "Partido actualizado correctamente" });
    } catch (error) {
        res.status(500).json({ error: "Error en la base de datos" });
    }
};

const deleteMatchById = async (req, res) => {
    const { id } = req.params;
    try {
        const result = await MatchesModel.deleteMatchById(id);
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Partido no encontrado o ya eliminado" });
        }
        res.json({ message: "Partido eliminado lógicamente" });
    } catch (error) {
        res.status(500).json({ error: "Error en la base de datos" });
    }
};

module.exports = {
    getMatches,
    getMatchById,
    createMatch,
    updateMatch,
    deleteMatchById
};
